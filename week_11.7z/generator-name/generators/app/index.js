var Generator = require('yeoman-generator');


module.exports = class extends Generator {
    // The name `constructor` is important here
    constructor(args, opts) {
      super(args, opts);
      this.writing = (title) => {
          const pkgJson = {
            devDependencies: {
              eslint: '^3.15.0'
            },
            dependencies: {
              react: '^16.2.0'
            }
          };
          this.fs.copyTpl(
            this.templatePath('t.html'),
            this.destinationPath('public/index.html'),
            { title: title }
          );
          this.fs.extendJSON(this.destinationPath('package.json'), pkgJson);
      }
    }

    async method1() {
      const answers = await this.prompt([
        {
          type: "input",
          name: "name",
          message: "Your project name",
          default: this.appname // Default to current folder name
        },
        {
          type: "input",
          name: "title",
          message: "Would you like to enable the title feature?",
          default: '我是一个标题'
        }
      ]);
      
      this.log("app name", answers.name);
      this.writing(answers.title)

    }
    install() {
      this.npmInstall();
    }
  };