var assert = require('assert');

import {parserHtml} from '../parser.js';

 		
describe('parser-html', function() {
    // 里面的内容会变成一个集合
    it('<a></a>', function() {
       let tree = parserHtml("<a></a>");
        assert.equal(tree.children[0].tagName, 'a');
        assert.equal(tree.children[0].children.length, 0);
    });

    it('<a>123</a>', function() {
        let tree = parserHtml("<a>123</a>");
         assert.equal(tree.children[0].tagName, 'a');
         assert.equal(tree.children[0].children.length, 1);
     });
     it('<a />', function() {
        let tree = parserHtml("<a />");
         assert.equal(tree.children.length, 1);
         assert.equal(tree.children[0].children.length, 0);
     });
     it('<a herf=\'www.baidu.com\'></a>', function() {
        let tree = parserHtml("<a herf='www.baidu.com'></a>");
         assert.equal(tree.children.length, 1);
         assert.equal(tree.children[0].children.length, 0);
     });
     it('<a herf>123</a>', function() {
        let tree = parserHtml("<a herf='www.baidu.com'>123</a>");
         assert.equal(tree.children.length, 1);
         assert.equal(tree.children[0].children.length, 1);
     });
     it('<a id=\"1\"></a>', function() {
        let tree = parserHtml("<a id=\"1\"></a>");
         assert.equal(tree.children.length, 1);
         assert.equal(tree.children[0].children.length, 0);
     });
     it('<a href id=\"1\"></a>', function() {
        let tree = parserHtml("<a href id=\"1\"></a>");
         assert.equal(tree.children.length, 1);
         console.log(tree)
         assert.equal(tree.children[0].children.length, 0);
     });
     it('<a id=\'1\' name=\'fanli\'></a>', function() {
        let tree = parserHtml("<a id=\'1\' name=\'fanli\'></a>");
         assert.equal(tree.children.length, 1);
         console.log(tree)
         assert.equal(tree.children[0].children.length, 0);
     });
})

