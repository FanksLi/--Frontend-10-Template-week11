var Generator = require('yeoman-generator');

module.exports = class extends Generator {
    constructor(args, opts) {
        super(args, opts);
    }

    async method() {
        const answers = await this.prompt([
            {
                type: 'input',
                name: 'name',
                message: 'Your project name',
                default: this.appname
            }
        ]);
        const pagJson = {
            "name": answers.name,
            "version": "1.0.0",
            "description": "",
            "main": "./src/index.js",
            "scripts": {
                "test": "mocha --require @babel/register",
                "coverage": "nyc npm run test"
            },
            "author": "",
            "license": "ISC",
            "dependencies": {
                "vue": "^2.5.16"
            },
            "devDependencies": {
              "html-webpack-plugin": "^5.3.2",
              "vue-loader": "^15.9.3",
              "vue-template-compiler": "^2.5.16",
              "webpack": "^5.42.0",
              "webpack-cli": "^4.7.2",
              "@babel/core": "^7.14.6",
              "@babel/preset-env": "^7.14.7",
              "@babel/register": "^7.14.5",
              "mocha": "^9.0.2",
              "nyc": "^15.1.0"
            }
        
        }
        this.fs.extendJSON(this.destinationPath('package.json'), pagJson);
        this.log('hello yeoman');
    }
    copyFile() {
        this.fs.copyTpl(
            this.templatePath('index.html'),
            this.destinationPath('public/index.html'),
            { title: 'Templating with Yeoman' }
        );
        this.fs.copyTpl(
           this.templatePath('index.js'),
           this.destinationPath('src/index.js'),
        );
        this.fs.copyTpl(
            this.templatePath('HelloWorld.vue'),
            this.destinationPath('src/HelloWorld.vue'),
         );
        this.fs.copyTpl(
           this.templatePath('webpack.config.js'),
           this.destinationPath('webpack.config.js'),
        );
        this.fs.copyTpl(
            this.templatePath('.babelrc'),
            this.destinationPath('.babelrc'),
         );
         this.fs.copyTpl(
            this.templatePath('test.js'),
            this.destinationPath('test/test.js'),
         );
    }
};