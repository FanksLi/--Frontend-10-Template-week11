<template>
    <div>hello world {{name}}</div>
</template>

<script>
export default {
    data() {
        return {
            name: '范里'
        }
    }
}
</script>
<style>

</style>
