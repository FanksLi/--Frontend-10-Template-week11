var assert = require('assert');


 		
describe('User', function() {
    // 里面的内容会变成一个集合
    it('is ok!', function() {
        assert.equal(1, 1);
    });
})

