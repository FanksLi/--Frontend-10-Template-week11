import Vue from 'vue';
import HelloWorld from './HelloWorld.vue';


new Vue({
    el: '#root',
    render: h => h(HelloWorld)
})