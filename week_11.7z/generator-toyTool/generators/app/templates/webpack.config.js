const {VueLoaderPlugin } = require('vue-loader');
const htmlWpackPlugin = require("html-webpack-plugin");

module.exports = {
    entry: './src/index.js',

    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader'
            }
        ]
    },
    plugins: [
        new VueLoaderPlugin(),
        new htmlWpackPlugin({
            template: './public/index.html'
        })
    ],
    mode: 'development'
}