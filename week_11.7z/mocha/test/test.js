var assert = require('assert');

import {add} from '../add.js';
// const add = require('../add.js');


 		
describe('User', function() {
    // 里面的内容会变成一个集合
    it('is add() 4', function() {
        assert.equal(add(1, 3), 4);
    });
    
    it('is add() -2', function() {
        assert.equal(add(-5, 3), -2);
    });
})

it('is add() 3', function() {
    assert.equal(add(0, 3), 3);
});