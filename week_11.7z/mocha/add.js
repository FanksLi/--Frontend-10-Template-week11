export function add(a, b) {
    return a + b;
}
export function nul(a, b) {
    return a * b;
}

// module.exports = add;